import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Square, c as Plus, d as Menu, f as Image, h as Check, i as Trash2, l as Play, m as Copy, n as Type, o as Send, p as Download, s as RefreshCw, t as X, u as PanelRight } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, f as Slot, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { t as k } from "../_libs/marked.mjs";
import { t as purify_default } from "../_libs/dompurify.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-cZDO4-Dt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[transform,background-color,color,box-shadow,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-foam text-abyss hover:bg-ink",
			ghost: "bg-transparent text-mist hover:bg-tide hover:text-ink",
			quiet: "bg-transparent text-mist hover:text-ink shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			danger: "bg-transparent text-danger hover:bg-danger/10"
		},
		size: {
			sm: "h-9 rounded-lg px-3 text-sm",
			md: "h-11 rounded-xl px-4 text-sm",
			icon: "size-11 rounded-xl",
			iconSm: "size-9 rounded-lg"
		},
		press: {
			yes: "active:not-disabled:scale-[0.96]",
			no: ""
		}
	},
	defaultVariants: {
		variant: "ghost",
		size: "md",
		press: "yes"
	}
});
function Button({ className, variant, size, press, asChild, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		type: asChild ? void 0 : type,
		className: cn(buttonVariants({
			variant,
			size,
			press,
			className
		})),
		...props
	});
}
function TooltipProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration: 250,
		skipDelayDuration: 150,
		children
	});
}
function Hint({ label, children, side = "bottom" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root3, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		asChild: true,
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		side,
		sideOffset: 8,
		className: cn("z-50 rounded-lg bg-lagoon px-2.5 py-1.5 text-xs text-foam shadow-[var(--shadow-border)]", "data-[state=delayed-open]:animate-in fade-in-0 zoom-in-95"),
		children: label
	}) })] });
}
function downloadText(filename, content, mime = "text/plain;charset=utf-8") {
	const blob = new Blob([content], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
}
function downloadDataUrl(filename, dataUrl) {
	const a = document.createElement("a");
	a.href = dataUrl;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
}
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
	} catch {
		const area = document.createElement("textarea");
		area.value = text;
		area.setAttribute("readonly", "");
		area.style.position = "fixed";
		area.style.left = "-9999px";
		document.body.appendChild(area);
		area.select();
		document.execCommand("copy");
		area.remove();
	}
}
function conversationToMarkdown(conversation) {
	const body = conversation.messages.map((message) => {
		return `## ${message.role === "user" ? "Kamu" : "Samudra"}\n\n${message.imageUrl ? `![gambar](${message.imageUrl})\n\n` : ""}${message.content}`.trim();
	}).join("\n\n---\n\n");
	return `# ${conversation.title}\n\n${body}\n`;
}
function mimeForFilename(filename) {
	if (filename.endsWith(".html")) return "text/html;charset=utf-8";
	if (filename.endsWith(".css")) return "text/css;charset=utf-8";
	if (filename.endsWith(".js")) return "text/javascript;charset=utf-8";
	if (filename.endsWith(".json")) return "application/json;charset=utf-8";
	if (filename.endsWith(".svg")) return "image/svg+xml;charset=utf-8";
	if (filename.endsWith(".md")) return "text/markdown;charset=utf-8";
	return "text/plain;charset=utf-8";
}
function CopyButton({ text, label = "Salin", className }) {
	const [done, setDone] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
		label: done ? "Tersalin" : label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "iconSm",
			className: cn("text-mist", className),
			"aria-label": label,
			onClick: async () => {
				await copyText(text);
				setDone(true);
				toast.success("Disalin");
				window.setTimeout(() => setDone(false), 1400);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative grid size-4 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: cn("absolute transition-[opacity,filter,scale] duration-300 ease-[cubic-bezier(0.2,0,0,1)]", done ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-none") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("absolute text-ok transition-[opacity,filter,scale] duration-300 ease-[cubic-bezier(0.2,0,0,1)]", done ? "scale-100 opacity-100 blur-none" : "scale-[0.25] opacity-0 blur-[4px]") })]
			})
		})
	});
}
function DownloadButton({ filename, content, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
		label: "Unduh",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "iconSm",
			className: cn("text-mist", className),
			"aria-label": "Unduh",
			onClick: () => {
				downloadText(filename, content, mimeForFilename(filename));
				toast.success(`Mengunduh ${filename}`);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
		})
	});
}
function RunButton({ onClick, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
		label: "Jalankan",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "iconSm",
			variant: "quiet",
			className: cn("text-accent", className),
			"aria-label": "Jalankan",
			onClick,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-px" })
		})
	});
}
function toRunnableDocument(lang, code) {
	const kind = lang.trim().toLowerCase();
	const source = code.trim();
	if (kind === "css") return `<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    html, body { margin: 0; min-height: 100%; background: #061018; color: #e6f2f4; font: 16px/1.5 Figtree, system-ui, sans-serif; }
    main { padding: 24px; max-width: 720px; margin: 0 auto; }
    .card { margin-top: 16px; padding: 16px; border: 1px solid rgba(230,242,244,.12); border-radius: 16px; }
    ${source}
  </style>
</head>
<body>
  <main>
    <h1>Pratinjau CSS</h1>
    <p>Gaya di blok kode diterapkan ke halaman ini.</p>
    <div class="card">Kartu contoh</div>
  </main>
</body>
</html>`;
	if (kind === "js" || kind === "javascript") return `<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    html, body { margin: 0; background: #061018; color: #d7ecea; }
    #out { font: 13px/1.55 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; padding: 16px; white-space: pre-wrap; }
    .err { color: #e07a72; }
  </style>
</head>
<body>
  <div id="out"></div>
  <script>
    const out = document.getElementById("out");
    const write = (cls, args) => {
      const line = document.createElement("div");
      if (cls) line.className = cls;
      line.textContent = args.map((a) => {
        if (a instanceof Error) return a.stack || a.message;
        if (typeof a === "object") {
          try { return JSON.stringify(a, null, 2); } catch { return String(a); }
        }
        return String(a);
      }).join(" ");
      out.appendChild(line);
    };
    console.log = (...a) => write("", a);
    console.warn = (...a) => write("", a);
    console.error = (...a) => write("err", a);
    try {
      ${source.replace(/<\/script/gi, "<\\/script")}
    } catch (error) {
      console.error(error);
    }
  <\/script>
</body>
</html>`;
	if (kind === "svg" || source.startsWith("<svg")) return `<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <style>html,body{margin:0;min-height:100%;background:#061018;display:grid;place-items:center}</style>
</head>
<body>${source}</body>
</html>`;
	if (!/<html/i.test(source)) return `<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>html,body{margin:0;min-height:100%}</style>
</head>
<body>${source}</body>
</html>`;
	return source;
}
var RUNNABLE = /* @__PURE__ */ new Set([
	"html",
	"htm",
	"svg",
	"css",
	"js",
	"javascript"
]);
function normalizeLang(raw) {
	const lang = raw.trim().toLowerCase().split(/[\s{]/)[0] ?? "";
	if (lang === "htm") return "html";
	if (lang === "javascript") return "js";
	return lang;
}
function isRunnable(lang) {
	return RUNNABLE.has(normalizeLang(lang));
}
function guessFilename(lang, index) {
	const map = {
		html: "index.html",
		htm: "index.html",
		svg: "mark.svg",
		css: "styles.css",
		js: "script.js",
		javascript: "script.js",
		ts: "script.ts",
		tsx: "component.tsx",
		jsx: "component.jsx",
		json: "data.json",
		py: "main.py",
		python: "main.py",
		md: "note.md",
		markdown: "note.md",
		txt: "note.txt",
		sh: "run.sh",
		bash: "run.sh"
	};
	const key = normalizeLang(lang);
	if (map[key]) {
		if (index === 0) return map[key];
		const [name, ext] = map[key].split(".");
		return `${name}-${index + 1}.${ext}`;
	}
	return `file-${index + 1}${key ? `.${key}` : ".txt"}`;
}
function splitFences(input) {
	const parts = [];
	const src = input;
	let cursor = 0;
	while (cursor < src.length) {
		const open = src.indexOf("```", cursor);
		if (open === -1) {
			const rest = src.slice(cursor);
			if (rest) parts.push({
				type: "text",
				text: rest
			});
			break;
		}
		if (open > cursor) parts.push({
			type: "text",
			text: src.slice(cursor, open)
		});
		const afterOpen = open + 3;
		const nl = src.indexOf("\n", afterOpen);
		if (nl === -1) {
			const lang = normalizeLang(src.slice(afterOpen));
			parts.push({
				type: "code",
				lang,
				code: "",
				closed: false
			});
			break;
		}
		const lang = normalizeLang(src.slice(afterOpen, nl));
		const close = src.indexOf("```", nl + 1);
		if (close === -1) {
			parts.push({
				type: "code",
				lang,
				code: src.slice(nl + 1),
				closed: false
			});
			break;
		}
		parts.push({
			type: "code",
			lang,
			code: src.slice(nl + 1, close).replace(/\n$/, ""),
			closed: true
		});
		cursor = close + 3;
		if (src[cursor] === "\n") cursor += 1;
	}
	return parts.filter((part) => part.type === "text" ? part.text.trim().length > 0 : true);
}
function extractArtifacts(content, messageId) {
	return splitFences(content).filter((part) => part.type === "code").map((part, index) => ({
		id: `${messageId}:${index}`,
		lang: part.lang || "txt",
		code: part.code,
		filename: guessFilename(part.lang, index),
		runnable: isRunnable(part.lang) && part.code.trim().length > 0,
		closed: part.closed
	}));
}
function titleFromPrompt(prompt) {
	const clean = prompt.replace(/\s+/g, " ").trim();
	if (!clean) return "Percakapan baru";
	return clean.length > 42 ? `${clean.slice(0, 42).trim()}…` : clean;
}
function ArtifactDock({ artifact, onClose, onCode, className }) {
	const [tab, setTab] = (0, import_react.useState)(artifact.lang ? "run" : "code");
	const [frameKey, setFrameKey] = (0, import_react.useState)(0);
	const runnable = isRunnable(artifact.lang);
	const srcDoc = (0, import_react.useMemo)(() => runnable ? toRunnableDocument(artifact.lang, artifact.code) : "", [
		artifact.code,
		artifact.lang,
		runnable
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("flex h-full min-h-0 flex-col bg-depth/90", className),
		"aria-label": "Ruang kerja",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-border px-3 py-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-foam",
							children: artifact.filename
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[11px] uppercase tracking-wide text-mist",
							children: artifact.lang || "teks"
						})]
					}),
					runnable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "iconSm",
						"aria-label": "Jalankan ulang",
						onClick: () => {
							setTab("run");
							setFrameKey((value) => value + 1);
						},
						children: tab === "run" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-px" })
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: artifact.code }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "iconSm",
						"aria-label": "Unduh berkas",
						onClick: () => {
							downloadText(artifact.filename, artifact.code, mimeForFilename(artifact.filename));
							toast.success(`Mengunduh ${artifact.filename}`);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "iconSm",
						"aria-label": "Tutup ruang kerja",
						onClick: onClose,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1 px-3 pt-2",
				children: [runnable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabChip, {
					active: tab === "run",
					onClick: () => setTab("run"),
					label: "Jalankan"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabChip, {
					active: tab === "code" || !runnable,
					onClick: () => setTab("code"),
					label: "Kode"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 p-3 pt-2",
				children: tab === "run" && runnable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: `Pratinjau ${artifact.filename}`,
					className: "h-full w-full rounded-xl bg-abyss shadow-[var(--shadow-border)]",
					sandbox: "allow-scripts allow-modals allow-forms",
					srcDoc
				}, frameKey) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: artifact.code,
					onChange: (event) => onCode(event.target.value),
					spellCheck: false,
					className: "h-full w-full resize-none rounded-xl bg-abyss p-3 font-mono text-[12.5px] leading-relaxed text-foam shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70",
					"aria-label": "Sunting kode"
				})
			})
		]
	});
}
function TabChip({ active, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 rounded-lg px-3 text-xs font-medium transition-colors duration-150", active ? "bg-tide text-foam" : "text-mist hover:text-ink"),
		children: label
	});
}
var Textarea = (0, import_react.forwardRef)(function Textarea({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		ref,
		className: cn("w-full resize-none bg-transparent text-base leading-relaxed text-ink placeholder:text-mist/80", "focus-visible:outline-none disabled:opacity-50", className),
		...props
	});
});
var MAX = 8e3;
function Composer({ value, onChange, mode, onMode, busy, onSend, onStop }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		el.style.height = "auto";
		el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
	}, [value]);
	function onKeyDown(event) {
		if (event.nativeEvent.isComposing) return;
		if (event.key === "Enter" && !event.shiftKey) {
			event.preventDefault();
			if (!busy) onSend();
		}
	}
	const canSend = value.trim().length > 0 && !busy;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto w-full max-w-3xl px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2 md:px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-tide/90 p-2 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				ref,
				rows: 1,
				value,
				maxLength: MAX,
				onChange: (event) => onChange(event.target.value),
				onKeyDown,
				placeholder: mode === "image" ? "Deskripsikan gambar yang ingin dibuat…" : "Tanya apa saja, minta kode, atau minta halaman yang bisa dijalankan…",
				"aria-label": mode === "image" ? "Deskripsi gambar" : "Pesan",
				className: "min-h-12 max-h-52 px-3 py-2.5"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 px-1 pb-0.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-xl bg-depth p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeChip, {
							active: mode === "chat",
							onClick: () => onMode("chat"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, { className: "size-3.5" }),
							label: "Teks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeChip, {
							active: mode === "image",
							onClick: () => onMode("image"),
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-3.5" }),
							label: "Gambar"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto pr-2 font-mono text-[11px] tabular-nums text-mist",
						children: [
							value.length,
							"/",
							MAX
						]
					}),
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
						label: "Hentikan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							size: "icon",
							"aria-label": "Hentikan",
							onClick: onStop,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "fill-current" })
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
						label: "Kirim",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							size: "icon",
							"aria-label": "Kirim",
							disabled: !canSend,
							onClick: onSend,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {})
						})
					})
				]
			})]
		})
	});
}
function ModeChip({ active, onClick, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-9 items-center gap-1.5 rounded-lg px-3 text-xs font-medium transition-colors duration-150", active ? "bg-tide text-foam" : "text-mist hover:text-ink"),
		"aria-pressed": active,
		children: [icon, label]
	});
}
function WaveMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("text-accent", className),
		fill: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M4 19c3.2 0 3.2-6 6.4-6s3.2 6 6.4 6 3.2-6 6.4-6 3.2 6 6.4 6",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinecap: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M4 24c3.2 0 3.2-4 6.4-4s3.2 4 6.4 4 3.2-4 6.4-4 3.2 4 6.4 4",
			stroke: "currentColor",
			strokeWidth: "1.3",
			strokeLinecap: "round",
			opacity: "0.45"
		})]
	});
}
k.setOptions({
	gfm: true,
	breaks: true
});
function MarkdownView({ text }) {
	const html = (0, import_react.useMemo)(() => {
		if (!text.trim()) return "";
		const dirty = k.parse(text, { async: false });
		if (typeof window === "undefined") return dirty;
		return purify_default.sanitize(dirty, { USE_PROFILES: { html: true } });
	}, [text]);
	if (!html) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "md-body",
		dangerouslySetInnerHTML: { __html: html }
	});
}
function MessageCard({ message, conversationId, streaming, onRun }) {
	const parts = (0, import_react.useMemo)(() => splitFences(message.content), [message.content]);
	const artifacts = (0, import_react.useMemo)(() => extractArtifacts(message.content, message.id), [message.content, message.id]);
	const isUser = message.role === "user";
	let codeCursor = 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("flex gap-3", isUser ? "flex-row-reverse" : "flex-row"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("mt-0.5 grid size-9 shrink-0 place-items-center rounded-lg", isUser ? "bg-tide text-foam" : "bg-lagoon text-accent"),
			"aria-hidden": "true",
			children: isUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium",
				children: "K"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaveMark, { className: "size-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("min-w-0 max-w-[min(100%,44rem)] flex-1", isUser && "flex flex-col items-end"),
			children: [isUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl rounded-tr-md bg-tide px-4 py-3 text-[0.9375rem] leading-relaxed text-ink",
				children: message.content
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					message.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-2xl bg-danger/10 px-4 py-3 text-sm text-danger",
						children: message.error
					}) : null,
					message.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "overflow-hidden rounded-2xl bg-tide shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: message.imageUrl,
							alt: message.content || "Gambar dari Samudra",
							className: "max-h-[28rem] w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "flex items-center justify-between gap-2 px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-xs text-mist",
								children: message.content
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-9 rounded-lg px-3 text-xs text-mist hover:text-ink",
								onClick: () => downloadDataUrl("samudra.png", message.imageUrl),
								children: "Unduh"
							})]
						})]
					}) : null,
					parts.map((part, index) => {
						if (part.type === "text") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownView, { text: part.text }, `${message.id}-t-${index}`);
						const artifact = artifacts[codeCursor];
						codeCursor += 1;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "overflow-hidden rounded-2xl bg-depth shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 border-b border-border px-3 py-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-[11px] uppercase tracking-wide text-mist",
										children: part.lang || "teks"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 flex-1 truncate text-xs text-mist/80",
										children: artifact?.filename
									}),
									artifact?.runnable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RunButton, { onClick: () => onRun({
										conversationId,
										messageId: message.id,
										artifactId: artifact.id,
										lang: artifact.lang,
										code: artifact.code,
										filename: artifact.filename
									}) }) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: part.code }),
									artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
										filename: artifact.filename,
										content: part.code
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "max-h-[22rem] overflow-auto px-4 py-3 font-mono text-[12.5px] leading-relaxed text-foam",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: part.code })
							})]
						}, `${message.id}-c-${index}`);
					}),
					streaming && !message.content && !message.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tide-shimmer text-sm",
						children: "Menyelam ke jawaban…"
					}) : null
				]
			}), !isUser && !streaming && message.content && !message.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
					text: message.content,
					label: "Salin jawaban"
				})
			}) : null]
		})]
	});
}
function OceanBackdrop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ocean-scene absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ocean-caustic absolute -inset-[12%]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 bottom-0 h-40 bg-linear-to-t from-abyss to-transparent" })
		]
	});
}
function Sidebar({ conversations, activeId, onNew, onSelect, onDelete, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex h-full flex-col bg-depth/80", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-4 pt-5 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaveMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg leading-tight tracking-tight text-foam",
						children: "Samudra"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-mist",
						children: "Studio AI"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "primary",
					className: "w-full",
					onClick: onNew,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Percakapan baru"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-4 min-h-0 flex-1 overflow-y-auto px-2 pb-3",
				"aria-label": "Riwayat percakapan",
				children: conversations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-6 text-sm text-mist",
					children: "Belum ada riwayat. Mulai dari ombak pertama."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1",
					children: conversations.map((chat) => {
						const active = chat.id === activeId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("group flex items-center gap-1 rounded-xl px-1", active ? "bg-tide" : "hover:bg-tide/60"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => onSelect(chat.id),
									className: "min-w-0 flex-1 rounded-xl px-3 py-2.5 text-left text-sm text-ink",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate",
										children: chat.title
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
									label: "Unduh markdown",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "iconSm",
										className: "opacity-100 md:opacity-0 md:group-hover:opacity-100",
										"aria-label": "Unduh percakapan",
										onClick: () => {
											downloadText(`${slug(chat.title)}.md`, conversationToMarkdown(chat), "text/markdown;charset=utf-8");
											toast.success("Percakapan diunduh");
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
									label: "Hapus",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "iconSm",
										variant: "danger",
										className: "opacity-100 md:opacity-0 md:group-hover:opacity-100",
										"aria-label": "Hapus percakapan",
										onClick: () => onDelete(chat.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
									})
								})
							]
						}) }, chat.id);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pb-[max(1rem,env(safe-area-inset-bottom))] text-[11px] leading-relaxed text-mist",
				children: "Model Grok. Riwayat tersimpan di perangkat ini."
			})
		]
	});
}
function slug(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 40) || "samudra";
}
async function streamChat(options) {
	const response = await fetch("/api/chat", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ messages: options.messages }),
		signal: options.signal
	});
	if (!response.ok) {
		let detail = `Permintaan gagal (${response.status})`;
		try {
			const payload = await response.json();
			if (payload.error) detail = payload.error;
		} catch {}
		throw new Error(detail);
	}
	if (!response.body) throw new Error("Aliran kosong dari server.");
	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let buffer = "";
	while (true) {
		const { done, value } = await reader.read();
		if (done) break;
		buffer += decoder.decode(value, { stream: true });
		const lines = buffer.split("\n");
		buffer = lines.pop() ?? "";
		for (const raw of lines) {
			const line = raw.trim();
			if (!line.startsWith("data:")) continue;
			const data = line.slice(5).trim();
			if (!data || data === "[DONE]") continue;
			try {
				const token = JSON.parse(data).choices?.[0]?.delta?.content;
				if (typeof token === "string" && token.length > 0) options.onDelta(token);
			} catch {}
		}
	}
}
async function generateImage(prompt, signal) {
	const response = await fetch("/api/image", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ prompt }),
		signal
	});
	const payload = await response.json();
	if (!response.ok || !payload.ok || !payload.image) throw new Error(payload.error ?? `Gambar gagal dibuat (${response.status})`);
	return payload.image;
}
var STORAGE_KEY = "samudra-studio-v1";
var MAX_CHATS = 40;
function snapshot(state) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			conversations: state.conversations.slice(0, MAX_CHATS),
			activeId: state.activeId
		}));
	} catch {
		try {
			const trimmed = state.conversations.slice(0, 8).map((chat) => ({
				...chat,
				messages: chat.messages.map((message) => message.imageUrl && message.imageUrl.length > 2e5 ? {
					...message,
					imageUrl: void 0,
					content: message.content || "(gambar tidak disimpan)"
				} : message)
			}));
			localStorage.setItem(STORAGE_KEY, JSON.stringify({
				conversations: trimmed,
				activeId: state.activeId
			}));
		} catch {}
	}
}
function load() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return {
			conversations: [],
			activeId: null
		};
		const parsed = JSON.parse(raw);
		const conversations = Array.isArray(parsed.conversations) ? parsed.conversations : [];
		return {
			conversations,
			activeId: parsed.activeId && conversations.some((chat) => chat.id === parsed.activeId) ? parsed.activeId : conversations[0]?.id ?? null
		};
	} catch {
		return {
			conversations: [],
			activeId: null
		};
	}
}
var useStudioStore = create((set, get) => ({
	hydrated: false,
	conversations: [],
	activeId: null,
	streamingId: null,
	artifact: null,
	hydrate: () => {
		if (get().hydrated) return;
		set({
			...load(),
			hydrated: true
		});
	},
	newChat: () => {
		const conversation = {
			id: uid(),
			title: "Percakapan baru",
			messages: [],
			updatedAt: Date.now()
		};
		set((state) => {
			const next = {
				conversations: [conversation, ...state.conversations].slice(0, MAX_CHATS),
				activeId: conversation.id
			};
			snapshot(next);
			return {
				...next,
				artifact: null
			};
		});
		return conversation.id;
	},
	setActive: (id) => {
		set((state) => {
			snapshot({
				conversations: state.conversations,
				activeId: id
			});
			return {
				activeId: id,
				artifact: null
			};
		});
	},
	deleteChat: (id) => {
		set((state) => {
			const conversations = state.conversations.filter((chat) => chat.id !== id);
			const next = {
				conversations,
				activeId: state.activeId === id ? conversations[0]?.id ?? null : state.activeId
			};
			snapshot(next);
			return {
				...next,
				artifact: state.artifact?.conversationId === id ? null : state.artifact
			};
		});
	},
	addMessage: (conversationId, message) => {
		const id = message.id ?? uid();
		set((state) => {
			const next = {
				conversations: state.conversations.map((chat) => {
					if (chat.id !== conversationId) return chat;
					const title = chat.messages.length === 0 && message.role === "user" ? titleFromPrompt(message.content) : chat.title;
					return {
						...chat,
						title,
						updatedAt: Date.now(),
						messages: [...chat.messages, {
							id,
							createdAt: Date.now(),
							role: message.role,
							content: message.content,
							imageUrl: message.imageUrl,
							error: message.error
						}].slice(-80)
					};
				}),
				activeId: state.activeId
			};
			snapshot(next);
			return next;
		});
		return id;
	},
	patchMessage: (conversationId, messageId, patch) => {
		set((state) => {
			const next = {
				conversations: state.conversations.map((chat) => {
					if (chat.id !== conversationId) return chat;
					return {
						...chat,
						updatedAt: Date.now(),
						messages: chat.messages.map((message) => message.id === messageId ? {
							...message,
							...patch
						} : message)
					};
				}),
				activeId: state.activeId
			};
			snapshot(next);
			return next;
		});
	},
	setStreaming: (id) => set({ streamingId: id }),
	openArtifact: (artifact) => set({ artifact }),
	closeArtifact: () => set({ artifact: null }),
	updateArtifactCode: (code) => set((state) => state.artifact ? { artifact: {
		...state.artifact,
		code
	} } : state)
}));
function selectActiveChat(state) {
	return state.conversations.find((chat) => chat.id === state.activeId) ?? null;
}
var STARTERS = [
	{
		title: "Restoran laut",
		blurb: "Halaman HTML lengkap, siap dijalankan.",
		prompt: "Buatkan halaman HTML lengkap, elegan, bertema restoran seafood pesisir. Sertakan hero, menu singkat, dan tombol reservasi. CSS di dalam file yang sama, tanpa dependensi."
	},
	{
		title: "Format rupiah",
		blurb: "Fungsi JavaScript plus contoh di konsol.",
		prompt: "Tulis fungsi JavaScript formatRupiah(angka) yang rapi, plus 4 contoh console.log. Kode harus bisa dijalankan langsung."
	},
	{
		title: "Pasang surut",
		blurb: "Penjelasan singkat dengan analogi yang jelas.",
		prompt: "Jelaskan cara kerja pasang surut laut dengan analogi yang mudah dipahami, lalu beri 3 fakta yang sering disalahpahami."
	},
	{
		title: "Game mutiara",
		blurb: "Mini game HTML satu file, keyboard dan sentuh.",
		prompt: "Buat mini game HTML satu file: pemain mengumpulkan mutiara dan menghindari arus. Keyboard dan sentuh. Tampilkan skor. Tanpa library eksternal."
	}
];
var BLANK_HTML = `<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Samudra</title>
  <style>
    :root { color-scheme: dark; }
    html, body {
      margin: 0;
      min-height: 100%;
      font: 16px/1.5 Figtree, system-ui, sans-serif;
      background: #061018;
      color: #e6f2f4;
    }
    main {
      min-height: 100dvh;
      display: grid;
      place-items: center;
      padding: 24px;
    }
    h1 { font-weight: 500; letter-spacing: -0.03em; }
    p { color: #8aa8b3; max-width: 28ch; }
  </style>
</head>
<body>
  <main>
    <div>
      <h1>Ruang kerja</h1>
      <p>Sunting kode di panel, lalu tekan jalankan.</p>
    </div>
  </main>
</body>
</html>
`;
function StudioApp() {
	const hydrate = useStudioStore((state) => state.hydrate);
	const conversations = useStudioStore((state) => state.conversations);
	const activeId = useStudioStore((state) => state.activeId);
	const streamingId = useStudioStore((state) => state.streamingId);
	const artifact = useStudioStore((state) => state.artifact);
	const newChat = useStudioStore((state) => state.newChat);
	const setActive = useStudioStore((state) => state.setActive);
	const deleteChat = useStudioStore((state) => state.deleteChat);
	const addMessage = useStudioStore((state) => state.addMessage);
	const patchMessage = useStudioStore((state) => state.patchMessage);
	const setStreaming = useStudioStore((state) => state.setStreaming);
	const openArtifact = useStudioStore((state) => state.openArtifact);
	const closeArtifact = useStudioStore((state) => state.closeArtifact);
	const updateArtifactCode = useStudioStore((state) => state.updateArtifactCode);
	const chat = useStudioStore(selectActiveChat);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)("chat");
	const [navOpen, setNavOpen] = (0, import_react.useState)(false);
	const [dockOpen, setDockOpen] = (0, import_react.useState)(false);
	const abortRef = (0, import_react.useRef)(null);
	const scrollerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const node = scrollerRef.current;
		if (!node) return;
		node.scrollTo({
			top: node.scrollHeight,
			behavior: "smooth"
		});
	}, [chat?.messages, streamingId]);
	const busy = Boolean(streamingId);
	const empty = !chat || chat.messages.length === 0;
	function ensureChat() {
		if (activeId && chat) return activeId;
		return newChat();
	}
	function stop() {
		abortRef.current?.abort();
		abortRef.current = null;
		setStreaming(null);
	}
	async function send(text = draft, sendMode = mode) {
		const prompt = text.trim();
		if (!prompt || busy) return;
		const conversationId = ensureChat();
		setDraft("");
		setNavOpen(false);
		addMessage(conversationId, {
			role: "user",
			content: prompt
		});
		const assistantId = addMessage(conversationId, {
			role: "assistant",
			content: ""
		});
		setStreaming(assistantId);
		const controller = new AbortController();
		abortRef.current = controller;
		try {
			if (sendMode === "image") {
				const image = await generateImage(prompt, controller.signal);
				patchMessage(conversationId, assistantId, {
					imageUrl: image,
					content: prompt
				});
				return;
			}
			const history = (useStudioStore.getState().conversations.find((item) => item.id === conversationId)?.messages ?? []).filter((message) => message.id !== assistantId && message.content.trim()).slice(-20).map((message) => ({
				role: message.role,
				content: message.content
			}));
			let assembled = "";
			await streamChat({
				messages: history,
				signal: controller.signal,
				onDelta: (chunk) => {
					assembled += chunk;
					patchMessage(conversationId, assistantId, { content: assembled });
				}
			});
			const last = extractArtifacts(assembled, assistantId).filter((item) => item.runnable).at(-1);
			if (last) {
				openArtifact({
					conversationId,
					messageId: assistantId,
					artifactId: last.id,
					lang: last.lang,
					code: last.code,
					filename: last.filename
				});
				if (window.matchMedia("(min-width: 1024px)").matches) setDockOpen(true);
			}
		} catch (error) {
			if (controller.signal.aborted) return;
			const message = error instanceof Error ? error.message : "Terjadi kesalahan.";
			patchMessage(conversationId, assistantId, { error: message });
		} finally {
			if (abortRef.current === controller) abortRef.current = null;
			setStreaming(null);
		}
	}
	function handleRun(next) {
		openArtifact(next);
		setDockOpen(true);
	}
	const mobileArtifact = (0, import_react.useMemo)(() => artifact, [artifact]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh overflow-hidden bg-abyss text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OceanBackdrop, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "relative z-10 hidden w-72 shrink-0 border-r border-border md:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
					conversations,
					activeId,
					onNew: () => {
						stop();
						newChat();
					},
					onSelect: (id) => {
						stop();
						setActive(id);
					},
					onDelete: deleteChat,
					className: "w-full"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex min-w-0 flex-1 flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "flex h-14 items-center gap-2 px-2 md:px-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									className: "md:hidden",
									"aria-label": "Buka percakapan",
									onClick: () => setNavOpen(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex min-w-0 items-center gap-2 md:hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaveMark, { className: "size-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-base tracking-tight",
										children: "Samudra"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "hidden truncate text-sm text-mist md:block",
									children: chat?.title ?? "Studio lautan"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "ml-auto flex items-center gap-1",
									children: artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										className: "md:hidden",
										"aria-label": "Buka ruang kerja",
										onClick: () => setDockOpen(true),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelRight, {})
									}) : null
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: scrollerRef,
							className: "min-h-0 flex-1 overflow-y-auto",
							children: empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								onPick: (prompt) => {
									setMode("chat");
									send(prompt, "chat");
								},
								onScratch: () => {
									openArtifact({
										conversationId: activeId ?? "scratch",
										messageId: "scratch",
										artifactId: "scratch",
										lang: "html",
										code: BLANK_HTML,
										filename: "index.html"
									});
									setDockOpen(true);
								}
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-4 pb-8",
								children: chat.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCard, {
									message,
									conversationId: chat.id,
									streaming: streamingId === message.id,
									onRun: handleRun
								}, message.id))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {
							value: draft,
							onChange: setDraft,
							mode,
							onMode: setMode,
							busy,
							onSend: () => void send(),
							onStop: stop
						})
					]
				}), artifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden w-[min(28rem,42vw)] shrink-0 border-l border-border lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArtifactDock, {
						artifact,
						onClose: closeArtifact,
						onCode: updateArtifactCode,
						className: "h-full"
					})
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: navOpen,
				onOpenChange: setNavOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-abyss/70 md:hidden" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: cn("fixed inset-y-0 left-0 z-50 w-[min(18.5rem,88vw)] outline-none md:hidden", "data-[state=open]:animate-in data-[state=closed]:animate-out"),
					"aria-describedby": void 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "sr-only",
						children: "Percakapan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
						conversations,
						activeId,
						onNew: () => {
							stop();
							newChat();
							setNavOpen(false);
						},
						onSelect: (id) => {
							stop();
							setActive(id);
							setNavOpen(false);
						},
						onDelete: deleteChat,
						className: "h-full border-r border-border"
					})]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(mobileArtifact) && dockOpen,
				onOpenChange: setDockOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-abyss/70 lg:hidden" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed inset-x-0 bottom-0 z-50 h-[min(88dvh,40rem)] outline-none lg:hidden",
					"aria-describedby": void 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "sr-only",
						children: "Ruang kerja"
					}), mobileArtifact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative h-full rounded-t-2xl border-t border-border bg-depth",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "iconSm",
								className: "absolute top-2.5 right-2 z-10",
								"aria-label": "Tutup",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArtifactDock, {
							artifact: mobileArtifact,
							onClose: () => {
								setDockOpen(false);
								closeArtifact();
							},
							onCode: updateArtifactCode,
							className: "h-full rounded-t-2xl"
						})]
					}) : null]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { classNames: { toast: "bg-lagoon text-ink border-border shadow-[var(--shadow-border)]" } }
			})
		]
	}) });
}
function EmptyState({ onPick, onScratch }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-full w-full max-w-3xl flex-col justify-center px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl leading-none tracking-tight text-foam md:text-5xl",
				children: "Samudra"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-sm leading-relaxed text-mist md:text-base",
				children: "Tempat AI untuk menulis, merancang, dan menjalankan ide. Salin, unduh, atau hidupkan kodenya di ruang kerja."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 grid gap-2 sm:grid-cols-2",
				children: STARTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPick(item.prompt),
					className: "h-full w-full rounded-2xl bg-tide/70 px-4 py-3.5 text-left shadow-[var(--shadow-border)] transition-[transform,box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)] active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-foam",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xs leading-relaxed text-mist",
						children: item.blurb
					})]
				}) }, item.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onScratch,
				className: "mt-4 self-start rounded-xl px-3 py-2 text-sm text-mist transition-colors hover:text-foam",
				children: "Atau buka ruang kerja kosong"
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
}
//#endregion
export { Home as component };
