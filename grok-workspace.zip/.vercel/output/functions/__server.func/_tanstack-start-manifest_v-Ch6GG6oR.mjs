//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ch6GG6oR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/chat",
			"/api/image"
		],
		preloads: ["/assets/index-BNpXStxS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BNpXStxS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BfP4Ynbt.js"]
	}
} });
//#endregion
export { tsrStartManifest };
